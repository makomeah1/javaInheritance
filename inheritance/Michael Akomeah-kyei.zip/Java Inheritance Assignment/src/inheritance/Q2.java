package inheritance;

public class Q2 {
	/*
	 Create a class named 'Member' having the following members:
Data members
1 - Name
2 - Age
3 - Phone number
4 - Address
5 - Salary
It also has a method named 'printSalary' which prints the salary of the members.
Two classes 'Employee' and 'Manager' inherits the 'Member' class. The
'Employee' and 'Manager' classes have data members 'specialization' and
'department' respectively. Now, assign name, age, phone number, address and
salary to an employee and a manager by making an object of both of these
classes and print the same.

	 */
	public static void main(String[]args) {
		
		Employee set =new Employee("Seth", 23, "23345632", "kumasi,Ghana", 2500,"Accountant");
		Manager Gab = new Manager("Gab", 23, "23345632", "Accra,Ghana", 3500,"CEO");
	       set.display();
	       Gab.display();

}

}


 class Member{
	private String Name;
	private  int Age;
	private String PhoneNumber;
    private String Address;
	private int Salary;
	 
	 
	public Member( String Name, int Age, String PhoneNumber,String Address,int Salary){
		 this.Name=Name;
		 this.Age=Age;
		 this.PhoneNumber=PhoneNumber;
		 this.Address=Address;
		 this.Salary=Salary;
		 
	 }
	 
	  void PrintSalary() {
		  System.out.println("The salary of the member: "+ Salary);		
	 }
	  
	  void display() {
		  System.out.println(Name +" "+Age+ " "+PhoneNumber+" "+ Salary);
	  }
 }
 
 class Employee extends Member{
	 
	private String Specialization; 	 
	 
	 Employee(String Name,int Age,String PhoneNumber,String Address,int Salary, String Specialization){
		 
		 super (Name, Age, PhoneNumber, Address, Salary);
		 this.Specialization = Specialization;
		 
	 }
 }
 
 class Manager extends Member{
	private String Department;
	
	 Manager(String Name,int Age,String PhoneNumber,String Address,int Salary,String Department){
		 super (Name, Age, PhoneNumber, Address, Salary);
		 this.Department=Department;
		 
		 
	 }
	 
 }
 
 
 
 
 