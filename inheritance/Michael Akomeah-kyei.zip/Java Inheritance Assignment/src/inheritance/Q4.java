package inheritance;

public class Q4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		square obj[]= new square[10];
		
		obj[0]=new square(3);
		obj[0].Area();
		obj[1]=new square(4);
		obj[1].Area();
		obj[2]=new square(5);
		obj[2].Area();
		obj[3]=new square(6);
		obj[3].Area();
		obj[4]=new square(7);
		obj[4].Area();
		obj[5]=new square(8);
		obj[5].Area();
		obj[6]=new square(9);
		obj[6].Area();
		obj[7]=new square(10);	
		obj[7].Area();
		obj[8]=new square(11);
		obj[8].Area();
		obj[9]=new square(12);	
		obj[9].Area();
}
}